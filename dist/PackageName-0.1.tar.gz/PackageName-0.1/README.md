# PackageName

This package uses recursion and sorting.

## Recursion

The recursion part of this package implements functions that return the sum of an array, the nth term in the fibonacci sequence, the factorial of a number and the reverse of a word.

## Sorting

The sorting part of this package implements functions that return a sorted array using the bubble sort, merge sort and quick sort methods.
